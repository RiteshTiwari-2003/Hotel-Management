Implementation is easy
just compile code and make sure a.out (file) is saved the same place as the files taking part in file handling
**VERY IMP.*** Password is potato!
