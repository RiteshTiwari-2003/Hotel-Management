This is a basic Hotel management database coded in C language and utilises file handling
Can run on windows as well as macOS and linux since it doesnt utilize obsolete libraries like conio.h